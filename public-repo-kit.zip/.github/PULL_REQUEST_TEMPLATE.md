## What and why

<!-- One paragraph. Link the issue. If this changes behaviour, name the design-doc section it follows (e.g. `02 §4`). -->

## Checklist

- [ ] Tests added or updated — detection changes include a positive case **and** a benign twin
- [ ] Docs updated in this PR where behaviour changed (with the right `Stage` tag)
- [ ] `CHANGELOG.md` line under *Unreleased*
- [ ] Commits are signed off (`git commit -s`) and follow Conventional Commits
- [ ] No secrets, no attack corpora, no captured real traffic
- [ ] Host-facing block error is still the opaque stub (`-32000`, reference only) — no tier/class/probability/segment on the wire
- [ ] No new server-facing headers (`Via`, `X-Forwarded-*`, `User-Agent`, `Server`)
- [ ] No `shell=True`; fail-closed behaviour preserved

## Security impact

<!-- Does this touch proxy/, cascade/, taint, pinning, spotlight, auth, audit or dashboard? If yes, two Code Owner reviews are required. Say what could go wrong if this change is subtly incorrect. -->

## Numbers

<!-- If you claim a latency, ASR or FPR figure, paste the `mcp-shield benchmark` output that produced it. Otherwise write "no numbers claimed". -->

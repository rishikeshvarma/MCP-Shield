# Changelog

All notable changes to MCP-Shield are recorded here. The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/); versions follow [SemVer](https://semver.org/).

## [Unreleased]

### Added
- Design documents `00`–`08`, `Host Prompt Rules.md` (v0.3), architecture diagrams, the dashboard prototype.

### Security
- (record every security-relevant change here, with the private advisory ID when one exists)
